package model.modelo;

import java.util.List;

public class Local {
    private String nome;
    private String descricao;


    public Local(String nome, String desc, List<Personagem> npcs) {
        this.nome = nome;
        this.descricao = desc;
    }

    // Getters and Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}