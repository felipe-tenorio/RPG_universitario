package model.modelo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sound.midi.VoiceStatus;

//armazena a situação acadêmica do jogador
public class Matricula {
    private List<Disciplina> disciplinasMatriculadas;
    private List<Disciplina> disciplinasCursadas;
    private Nota nota;
    private List<Double> notasMaterias;
    private CalendarioLetivo calendario;

    public Matricula() {
        this.disciplinasCursadas = new ArrayList<>();
        this.disciplinasMatriculadas = new ArrayList<>();
        this.nota = new Nota();
        this.notasMaterias = nota.getNotas();
        this.calendario = new CalendarioLetivo();
    }

    public void cursarDisciplina(Disciplina materia) {
        List<Disciplina> matriculadas = this.getDisciplinasMatriculadas();
        matriculadas.add(materia);
        this.setDisciplinasMatriculadas(matriculadas);
    }

    // Getters and Setters
    public List<Disciplina> getDisciplinasMatriculadas() {
        return disciplinasMatriculadas;
    }

    public void setDisciplinasMatriculadas(List<Disciplina> disciplinasMatriculadas) {
        this.disciplinasMatriculadas = disciplinasMatriculadas;
    }

    public List<Disciplina> getDisciplinasCursadas() {
        return disciplinasCursadas;
    }

    public void setDisciplinasCursadas(List<Disciplina> disciplinasCursadas) {
        this.disciplinasCursadas = disciplinasCursadas;
    }
    
    public Nota getNota() {
    	return nota;
    }
    
    public void setNota(Nota nota) {
    	this.nota = nota;
    }

    public List<Double> getNotas() {
        return notasMaterias;
    }

    public void setNotas(List<Double> notas) {
        this.notasMaterias = notas;
    }

    public CalendarioLetivo getCalendario() {
        return calendario;
    }

    public void setCalendario(CalendarioLetivo calendario) {
        this.calendario = calendario;
    }
}