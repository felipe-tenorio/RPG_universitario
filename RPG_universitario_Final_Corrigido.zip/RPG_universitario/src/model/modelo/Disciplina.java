package model.modelo;

import java.util.ArrayList;
import java.util.Map;
import java.util.List;

public class Disciplina {
    private String nome;
    private int cargaHoraria;
    private Professor professor;
    private int semestre;
    private String status;

    public Disciplina(String nome, int ch, Professor professor, int sem, String status) {
        this.nome = nome;
        this.cargaHoraria = ch;
        this.professor = professor;
        this.semestre = sem;
        this.status = status;
    }

    //Registra uma nova nota para o jogador nesta disciplina através da matrícula.
    public void registrarNota(Matricula matricula, double valor) {
       Nota disciplinas = matricula.getNota();

       	for(int i = 0; i < disciplinas.getDisciplina().size(); i++) {
       		if (disciplinas.getNotas().contains(null) == false){
       			List<Double> notas = disciplinas.getNotas();
       			notas.add(valor);
       			Double sum = disciplinas.somatorioNotas(notas);
       			disciplinas.makeNota(nome, sum);
       			matricula.setNotas(disciplinas.getNotas());
       		} else {
       			// Caso seja a primeira nota, cria uma nova lista de notas para essa disciplina
       			List<Double> notas = new ArrayList<>();
       			notas.add(valor);
       			disciplinas.makeNota(nome, disciplinas.somatorioNotas(notas));
       			matricula.setNotas(disciplinas.getNotas());
       		}
       		
       	}
    }

    // Getters and Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public Professor getProfessor(){
        return professor;
    }

    public void setProfessor(Professor professor){
        this.professor = professor;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}