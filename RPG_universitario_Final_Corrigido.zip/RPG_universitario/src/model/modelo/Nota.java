package model.modelo;

import java.util.ArrayList;
import java.util.List;

public class Nota {
	private List<String> disciplinas;
	private List<Double> notas;
	
	public Nota() {
		notas = new ArrayList<Double>();
		disciplinas = new ArrayList<String>();
	}
	
	public Nota(List<String> disciplina, List<Double> notas) {
		this.disciplinas = disciplina;
		this.notas = notas;
	}
	
	public Nota(String disciplina, Double nota) {
		disciplinas.add(disciplina);
		notas.add(nota);
	}
	
	public Double somatorioNotas(List<Double> notas) {
		double somatorio = 0;
		for(double n: notas) {
			somatorio += n;
		}
		return somatorio;
	}

	public List<String> getDisciplina() {
		return disciplinas;
	}

	public void setDisciplina(List<String> disciplina) {
		this.disciplinas = disciplina;
	}

	public List<Double> getNotas() {
		return notas;
	}

	public void setNotas(List<Double> notas) {
		this.notas = notas;
	}
	public Nota makeNota(String materia, Double nota) {
		return new Nota(materia, nota);
	}
	
}
