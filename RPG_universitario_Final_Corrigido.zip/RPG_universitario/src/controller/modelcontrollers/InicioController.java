package controller.modelcontrollers;

import java.util.List;
import java.util.Random;

import model.modelo.Jogador;
import model.modelo.Jogo;
import model.modelo.Local;

//Classe para gerar um novo jogo proceduralmente

public class InicioController {
	private Jogo gerador;
	private Random random;
	
	public InicioController() {
		gerador = new Jogo();
		random = new Random();
	}
	
	
	public Jogo getGerador() {
		return gerador;
	}


	public void setGerador(Jogo gerador) {
		this.gerador = gerador;
	}
	
	public Jogador criarJogador(String nomeJogador) {
		return new Jogador(nomeJogador);
	}

	// Inicialização de novo jogo
	public Jogo novoJogo(String nomeJogador){
		Jogador jogador = criarJogador(nomeJogador);
	    gerador.setJogador(jogador); 
		String[] eventoNormal = {"Prova 1", "Prova 2", "Prova 3", "Formatura"};
		String[] eventoAleatorio = {"Greve", "Fila Grande", "Prova Surpresa", "Milagre Acadêmico"};
		String[] tipoAnimal = {"Cachorro", "Gato"};
		String[] nomeDisciplinas = {"Software", "Hardware", "Cálculo", "PBL"};
		String[] nomeAnimal = {"Scooby", "Penélope", "Rex", "July", "Mateus", "Ambrósio", "Rex", "Thor", "Buddy", "Max", "Charlie",
		        "Rocky", "Toby", "Bolt", "Spike", "Duke",
		        "Zeus", "Apollo", "Sansão", "Brutus", "Simba",
		        "Fred", "Boris", "Lobo", "Marley", "Bidu",
		        "Scooby", "Pluto", "Beethoven", "Laika", "Totó",
		        "Luna", "Mimi", "Felix", "Garfield", "Tom",
		        "Mingau", "Salem", "Bola de Neve", "Frajola", "Marie",
		        "Chanel", "Nina", "Miau", "Oliver", "Lúcifer",
		        "Bella", "Mel", "Pipoca", "Amora", "Fumaça",
		        "Cacau", "Paçoca", "Jade", "Safira", "Lili"};
		
		String[] nomeNpc = {"Ana Silva", "Bruno Costa", "Carla Oliveira", "Daniel Souza", "Eduarda Lima",
		        "Felipe Santos", "Gabriela Pereira", "Henrique Almeida", "Isabela Rocha", "João Pedro",
		        "Karina Martins", "Lucas Ferreira", "Marina Barbosa", "Nicolas Ribeiro", "Olivia Cardoso",
		        "Pedro Henrique", "Quintino Duarte", "Rafaela Nunes", "Samuel Gomes", "Tatiane Azevedo",
		        "Ubiratan Campos", "Vanessa Teixeira", "William Moraes", "Xênia Borges", "Yago Monteiro",
		        "Alice Rodrigues", "Bernardo Lopes", "Camila Freitas", "Diego Castro", "Elaine Neves",
		        "Fabrício Mendes", "Gisele Xavier", "Hugo Farias", "Ingrid Sá", "Júlio César",
		        "Kelly Andrade", "Leonardo Pinto", "Mônica Barreto", "Natália Guimarães", "Otávio Vieira",
		        "Patrícia Leal", "Quésia Dantas", "Renato Carneiro", "Sílvia Fogaça", "Thiago Prado",
		        "Ulisses Magalhães", "Vitória Maciel", "Wilson Batista", "Xerxes Gomes", "Yara Coutinho", "Zélia Tavares"};
		
		String[] nomeProfessor = {"Roberto Carvalho", "Maria Helena", "Antônio Carlos", "Margarida Fonseca", "Francisco Assis",
		        "Tereza Cristina", "José Ricardo", "Vera Lúcia", "Paulo Sérgio", "Fátima Aparecida",
		        "Carlos Eduardo", "Sônia Regina", "Marcos Vinícius", "Rita de Cássia", "Luiz Fernando",
		        "Cristina Maria", "Ricardo José", "Patrícia Helena", "Sérgio Augusto", "Cláudia Regina",
		        "Fernando César", "Luciana Mara", "Eduardo Luís", "Rosângela Maria", "Marcelo Tadeu",
		        "Adriana Beatriz", "Rogério Almeida", "Denise Silveira", "Jorge Wilson", "Elisabete Cristina"};
		
		gerador.criarLocal("Módulo 3", "Módulo de Engenharia de Computação");
		gerador.criarLocal("Cantina", "Lugar de Alimentação e Socialização do Módulo");
		gerador.criarLocal("Ponto de Ônibus", null);
		List<Local> locais = gerador.getLocais();
		
		for(Integer i = 0; i < 10; i++) {
			gerador.criarLocal("Sala 3" +i.toString(), null);
			gerador.criarLocal("Laboratorio 3" +i.toString(), null);
		}
		for(Integer j = 0; j < random.nextInt(5, 50); j++) {
			gerador.criarAnimal(nomeAnimal[random.nextInt(0, nomeAnimal.length)], gerador.getLocais().get(random.nextInt(0, gerador.getLocais().size())), tipoAnimal[random.nextInt(0, tipoAnimal.length)]);
			gerador.criarPersonagem(nomeNpc[random.nextInt(0, nomeNpc.length)], gerador.getLocais().get(random.nextInt(0, gerador.getLocais().size())));
			gerador.criarProfessor(nomeProfessor[random.nextInt(0, nomeProfessor.length)], locais.get(random.nextInt(0, locais.size())), random.nextDouble(10.0), "Olá, sejam bem vindos à UEFS");
		}
		gerador.criarPersonagem("Maeli", new Local("Colegiado", "Apoio ao Aluno", gerador.getNpcs()));
		
		for(Integer i = 0; i < nomeDisciplinas.length; i++) {
			int aleatorio = random.nextInt(0, nomeDisciplinas.length);
			int cargahoraria = 60;
			gerador.criarEventosNormais(eventoNormal[aleatorio], "Um dos eventos já criados", null, null);
			gerador.criarEventosAleatorios(eventoAleatorio[aleatorio], null, null, null, random.nextFloat(100));
			gerador.criarDisciplina(nomeDisciplinas[aleatorio], cargahoraria, gerador.getProfessores().get(aleatorio), 1, "Cursando");
			eventoNormal[aleatorio] = null;
			eventoAleatorio[aleatorio] = null;
			nomeDisciplinas[aleatorio] = null;
		}
		return gerador;
	}
}
