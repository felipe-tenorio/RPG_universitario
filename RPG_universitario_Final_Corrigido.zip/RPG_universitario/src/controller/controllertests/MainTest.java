package controller.controllertests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.lang.classfile.instruction.NewMultiArrayInstruction;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;

import controller.MainController;
import controller.modelcontrollers.InicioController;
import controller.persistencia.savecontroller.SaveObject;
import model.modelo.Jogo;
import view.ViewTerminal;

//Classe de teste da main
class MainTest {
	MainController controller = new MainController("teste");
	//Testa se a construção deu certo
    @Test
    void testConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getView());
        assertNotNull(controller.getInicializador());
        assertNotNull(controller.getPersistencia());
    }
    
    //Testa getters e setters dos atributos da classe
    @Test
    void testGetView() {
        MainController controller = new MainController("teste");
        assertTrue(controller.getView() instanceof ViewTerminal);
    }

    @Test
    void testSetView() {
        MainController controller = new MainController("teste");
        ViewTerminal novaView = new ViewTerminal();
        controller.setView(novaView);
        assertEquals(novaView, controller.getView());
    }

    @Test
    void testGetInicializador() {
        MainController controller = new MainController("teste");
        assertTrue(controller.getInicializador() instanceof InicioController);
    }

    @Test
    void testSetInicializador() {
        MainController controller = new MainController("teste");
        InicioController novoInicializador = new InicioController();
        controller.setInicializador(novoInicializador);
        assertEquals(novoInicializador, controller.getInicializador());
    }

    @Test
    void testGetPersistencia() {
        MainController controller = new MainController("teste");
        assertTrue(controller.getPersistencia() instanceof SaveObject);
    }

    @Test
    void testSetPersistencia() {
        MainController controller = new MainController("teste");
        SaveObject novaPersistencia = new SaveObject("novo.json");
        controller.setPersistencia(novaPersistencia);
        assertEquals(novaPersistencia, controller.getPersistencia());
    }
    
    //Testa se dois atributos são diferentes se os construtores são diferentes
    @Test
    void testConstrutorComNomeDiferente() {
        MainController controller1 = new MainController("jogo1");
        MainController controller2 = new MainController("jogo2");
        assertNotEquals(controller1.getPersistencia(), controller2.getPersistencia());
    }
    
    //Testa se o objeto existe após o construtor
    @Test
    void testViewNaoENulaAposConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getView());
    }

    @Test
    void testInicializadorNaoENuloAposConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getInicializador());
    }

    @Test
    void testPersistenciaNaoENulaAposConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getPersistencia());
    }
    
    //Testagem de atributos null
    @Test
    void testSetViewComNull() {
        MainController controller = new MainController("teste");
        controller.setView(null);
        assertNull(controller.getView());
    }
    
    @Test
    void testSetInicializadorComNull() {
        MainController controller = new MainController("teste");
        controller.setInicializador(null);
        assertNull(controller.getInicializador());
    }
    
    @Test
    void testSetPersistenciaComNull() {
        MainController controller = new MainController("teste");
        controller.setPersistencia(null);
        assertNull(controller.getPersistencia());
    }
    
    @Test
    void testSetSalvarJogo() throws IOException {
    	MainController controller = new MainController("Jogos.json");
    	MainController.main(null);
    	if(controller.getView().mostrarMenuDeAcoes() == 8) {
    		fail("Falhou na persistencia");
    	}
    	assertEquals(controller.getInicializador().getGerador(), controller.getPersistencia().lerLista(Jogo.class));
    }
    
    @Test
	void test() throws IOException {
		if(controller.getPersistencia().arquivoExiste() == false) {
			System.out.println("ARQUIVO NÃO EXISTE");
		}
		else if(controller.getPersistencia().arquivoExiste()){
			System.out.println("ARQUIVO EXISTE!");
		}
		SaveObject persistencia = controller.getPersistencia();
		persistencia.salvarLista(controller.getJogos());
		
		MainController jogo = persistencia.lerObjeto(MainController.class);
		assertEquals(controller, jogo);
	}
	
	@Test
	void TestMain(Jogo novoJogo, List<Jogo> jogos) throws IOException {
		Random random = new Random();
		
		int acao = controller.getView().mostrarMenuPrincipal();
		while(acao != 9) {
			if(acao == 1) {
				novoJogo.getJogador().estudar();
			}
			else if(acao == 2) {
				novoJogo.getJogador().adquirirLanches(random.nextDouble(novoJogo.getJogador().getDinheiro()));
				if(novoJogo.getJogador().getDinheiro() == 0) {
					controller.getView().exibirMensagem("Você está sem dinheiro!");
				}
			}
			else if(acao == 3) {
				novoJogo.getJogador().fazerAvaliacao(novoJogo.getDisciplinas().get(random.nextInt(novoJogo.getDisciplinas().size())));
			}
			else if(acao == 4) {
				novoJogo.getJogador().acariciarAnimal(novoJogo.getAnimais().get(random.nextInt(novoJogo.getAnimais().size())));
			}
			else if(acao == 5) {
				novoJogo.getJogador().pegarOnibus(novoJogo.getLocais().get(random.nextInt(novoJogo.getLocais().size())));
			}
				
			else if(acao == 8) {
				int i = jogos.indexOf(novoJogo);
				jogos.add(i, novoJogo);
				controller.getPersistencia().salvarLista(jogos);
				
			}
			else {
				
			}
			controller.getView().mostrarMenuDeAcoes();
		}

	}
}