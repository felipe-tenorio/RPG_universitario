package controller.controllertests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;

import controller.MainController;
import controller.persistencia.savecontroller.SaveObject;
import model.modelo.Jogo;

class MainTest2 {
	MainController controller = new MainController("Jogo.json");

	@Test
	void test() throws IOException {
		if(controller.getPersistencia().arquivoExiste() == false) {
			System.out.println("ARQUIVO NÃO EXISTE");
		}
		else if(controller.getPersistencia().arquivoExiste()){
			System.out.println("ARQUIVO EXISTE!");
		}
		SaveObject persistencia = controller.getPersistencia();
		persistencia.salvarLista(controller.getJogos());
		
		MainController jogo = persistencia.lerObjeto(MainController.class);
		assertEquals(controller, jogo);
	}
	
	@Test
	void TestMain(Jogo novoJogo, List<Jogo> jogos) throws IOException {
		Random random = new Random();
		
		int acao = controller.getView().mostrarMenuPrincipal();
		while(acao != 9) {
			if(acao == 1) {
				novoJogo.getJogador().estudar();
			}
			else if(acao == 2) {
				novoJogo.getJogador().adquirirLanches(random.nextDouble(novoJogo.getJogador().getDinheiro()));
				if(novoJogo.getJogador().getDinheiro() == 0) {
					controller.getView().exibirMensagem("Você está sem dinheiro!");
				}
			}
			else if(acao == 3) {
				novoJogo.getJogador().fazerAvaliacao(novoJogo.getDisciplinas().get(random.nextInt(novoJogo.getDisciplinas().size())));
			}
			else if(acao == 4) {
				novoJogo.getJogador().acariciarAnimal(novoJogo.getAnimais().get(random.nextInt(novoJogo.getAnimais().size())));
			}
			else if(acao == 5) {
				novoJogo.getJogador().pegarOnibus(novoJogo.getLocais().get(random.nextInt(novoJogo.getLocais().size())));
			}
				
			else if(acao == 8) {
				int i = jogos.indexOf(novoJogo);
				jogos.add(i, novoJogo);
				controller.getPersistencia().salvarLista(jogos);
				
			}
			else {
				
			}
			controller.getView().mostrarMenuDeAcoes();
		}

	}

}
