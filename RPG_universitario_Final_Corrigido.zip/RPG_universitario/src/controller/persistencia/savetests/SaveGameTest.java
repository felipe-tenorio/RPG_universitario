package controller.persistencia.savetests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import controller.modelcontrollers.InicioController;
import controller.persistencia.savecontroller.SaveObject;
import model.modelo.Jogo;

class SaveGameTest {
	InicioController gerador;
	List<Jogo> jogos;
	Jogo jogoAtual;
	SaveObject persistencia;
	Jogo jogoAntigo;
	
	public SaveGameTest() {
		gerador = new InicioController();
		jogoAntigo = gerador.novoJogo("Melysso");
		jogoAtual = gerador.novoJogo("JV");
		jogos = new ArrayList<Jogo>();
		persistencia = new SaveObject("SaveGameTest.json");
	}
	
	@Test
	void SaveTest() throws IOException {
		jogos.add(jogoAntigo);
		jogos.add(jogoAtual);
		persistencia.salvarLista(jogos);
		assertTrue(persistencia.arquivoExiste());
	}
	
	@Test
	void ReadFileTest() throws IOException {
		try {
			List<Jogo> jogoRecuperado = persistencia.lerLista(Jogo.class);
			assertEquals(jogoAntigo.getJogador().getNome(), jogoRecuperado.get(0).getJogador().getNome());
		} catch (IOException e) {
			System.out.println("Deu erro aqui: ");
			System.out.println(e.toString());
		}
	}
}
