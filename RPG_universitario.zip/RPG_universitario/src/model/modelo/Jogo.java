package model.modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Jogo {
	private Jogador jogador;
	private CalendarioLetivo calendario;
	private List<Animal> animais;
	private List<Disciplina> disciplinas;
	private List<Personagem> npcs;
	private List<Professor> professores;
	private List<Local> locais;
	private List<Evento> eventosNormais;
	private List<EventoAleatorio> eventosAleatorios;
	
	public Jogo() {
		calendario = new CalendarioLetivo();
		animais = new ArrayList<Animal>();
		disciplinas = new ArrayList<Disciplina>();
		npcs = new ArrayList<Personagem>();
		professores = new ArrayList<Professor>();
		locais = new ArrayList<Local>();
		eventosNormais = new ArrayList<Evento>();
		eventosAleatorios = new ArrayList<EventoAleatorio>();
	}
	
	public List<Animal> criarAnimal(String nome, Local local, String tipo) {
		animais.add(new Animal(nome, local, tipo));
		return animais;
	}
	
	public List<Disciplina> criarDisciplina(String nome, int cargahoraria, Professor professor, int semestre, String status) {
		disciplinas.add(new Disciplina(nome, cargahoraria, professor, semestre, status));
		return disciplinas;
	}
	
	public List<Personagem> criarPersonagem(String nome, Local local) {
		npcs.add(new Personagem(nome, local));
		return npcs;
	}
	
	public List<Professor> criarProfessor(String nome, Local local, Double rigidez, String fala) {
		professores.add(new Professor(nome, local, rigidez, fala));
		return professores;
	}
	
	public List<Local> criarLocal(String nome, String descricao) {
		locais.add(new Local(nome, nome, npcs));
		return locais;
	}
	
	public void criarEventosNormais(String nome, String descricao, String condicaoAtivacao, Map<String, Double> efeitos) {
		eventosNormais.add(new Evento(nome, descricao, condicaoAtivacao, efeitos));
	}
	
	public List<EventoAleatorio> criarEventosAleatorios(String nome, String descricao, String condicaoAtivacao, Map<String, Double> efeitos, Float probabilidade) {
		eventosAleatorios.add(new EventoAleatorio(nome, descricao, condicaoAtivacao, efeitos, probabilidade));
		return eventosAleatorios;
	}
	
	public Jogador getJogador() {
		return jogador;
	}

	public void setJogador(Jogador jogador) {
		this.jogador = jogador;
	}

	public CalendarioLetivo getCalendario() {
		return calendario;
	}

	public void setCalendario(CalendarioLetivo calendario) {
		this.calendario = calendario;
	}

	public List<Animal> getAnimais() {
		return animais;
	}

	public void setAnimais(List<Animal> animais) {
		this.animais = animais;
	}

	public List<Disciplina> getDisciplinas() {
		return disciplinas;
	}

	public void setDisciplinas(List<Disciplina> disciplinas) {
		this.disciplinas = disciplinas;
	}

	public List<Personagem> getNpcs() {
		return npcs;
	}

	public void setNpcs(List<Personagem> npcs) {
		this.npcs = npcs;
	}

	public List<Professor> getProfessores() {
		return professores;
	}

	public void setProfessores(List<Professor> professores) {
		this.professores = professores;
	}

	public List<Local> getLocais() {
		return locais;
	}

	public void setLocais(List<Local> locais) {
		this.locais = locais;
	}

	public List<Evento> getEventosNormais() {
		return eventosNormais;
	}

	public void setEventosNormais(List<Evento> eventosNormais) {
		this.eventosNormais = eventosNormais;
	}

	public List<EventoAleatorio> getEventosAleatorios() {
		return eventosAleatorios;
	}

	public void setEventosAleatorios(List<EventoAleatorio> eventosAleatorios) {
		this.eventosAleatorios = eventosAleatorios;
	}
	
	public <E> Object procurarObjeto(String elemento, List<E> listaElementos){
		Object element = new Object();
		for(E elem: listaElementos) {
			if(elem.toString().equals(elemento)) {
				return elem;
			}
			else if(!listaElementos.contains(elem)){
				listaElementos.add(elem);
				element = elem;
				return elem;
			}
		}
		return element;
		
	}
}
