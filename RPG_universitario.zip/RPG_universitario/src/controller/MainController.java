package controller;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


import controller.modelcontrollers.*;
import controller.persistencia.savecontroller.SaveObject;
import model.modelo.Jogo;
import view.ViewTerminal;

//Controller principal (possui um método main para fazer o código inteiro rodar usando a ViewTerminal)
public class MainController {
	private ViewTerminal view;
	private InicioController inicializador;
	private SaveObject persistencia;
	
	//Construtor
	public MainController(String nomearquivo) {
		view = new ViewTerminal();
		 inicializador = new InicioController();
		 persistencia = new SaveObject(nomearquivo + ".json");
	}
	
	//Getters e Setters
	public ViewTerminal getView() {
		return view;
	}
	
	public void setView(ViewTerminal view) {
		this.view = view;
	}
	
	public InicioController getInicializador() {
		return inicializador;
	}

	public void setInicializador(InicioController inicializador) {
		this.inicializador = inicializador;
	}

	public SaveObject getPersistencia() {
		return persistencia;
	}

	public void setPersistencia(SaveObject persistencia) {
		this.persistencia = persistencia;
	}
	
	//Método de rodar o loop principal do jogo
	public void rodarJogo(Jogo novoJogo, List<Jogo> jogos) throws IOException {
		Random random = new Random();
		
		int acao = view.mostrarMenuDeAcoes();
		while(acao != 9) {
			if(acao == 1) {
				novoJogo.getJogador().estudar();
			}
			if(acao == 2) {
				novoJogo.getJogador().adquirirLanches(random.nextDouble(novoJogo.getJogador().getDinheiro()));
				if(novoJogo.getJogador().getDinheiro() == 0) {
					view.exibirMensagem("Você está sem dinheiro!");
				}
			}
			if(acao == 3) {
				novoJogo.getJogador().fazerAvaliacao(novoJogo.getDisciplinas().get(random.nextInt(novoJogo.getDisciplinas().size())));
			}
			if(acao == 4) {
				novoJogo.getJogador().acariciarAnimal(novoJogo.getAnimais().get(random.nextInt(novoJogo.getAnimais().size())));
			}
			if(acao == 5) {
				novoJogo.getJogador().pegarOnibus(novoJogo.getLocais().get(random.nextInt(novoJogo.getLocais().size())));
			}
			if(acao == 8) {
				int i = jogos.indexOf(novoJogo);
				jogos.add(i, novoJogo);
				persistencia.salvarLista(jogos);
				
			}
			view.mostrarMenuDeAcoes();
		}
	}

	
	//Método main (puxa a view para o controller) que decide o que fazer com cada entrada da View
	public static void main(String[] args) throws IOException {
		MainController controleGeral = new MainController("Jogos");
		ViewTerminal view = controleGeral.getView();
		InicioController inicializador = controleGeral.getInicializador();
		SaveObject persistencia = controleGeral.getPersistencia();
		
		int opcao = view.mostrarMenuPrincipal();
		List<Jogo> jogos = new ArrayList<Jogo>();
		
		if(opcao == 1) {
			Jogo novoJogo = inicializador.novoJogo(view.pedirNomeJogador());
			jogos.add(novoJogo);
			persistencia.salvarLista(jogos);
			controleGeral.rodarJogo(novoJogo, jogos);
		}
	
		else if(opcao == 2) {
			List<Jogo> jogosExistentes = persistencia.lerLista(Jogo.class);
			Jogo jogoSalvo = jogosExistentes.get(jogosExistentes.size()-1);
			controleGeral.rodarJogo(jogoSalvo, jogos);
		}
		else if(opcao == 3) {
			view.exibirMensagem("Saindo do jogo...");
		}
	}
}
