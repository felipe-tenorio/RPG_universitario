package controller.controllertests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import controller.MainController;
import controller.modelcontrollers.InicioController;
import controller.persistencia.savecontroller.SaveObject;
import view.ViewTerminal;

//Classe de teste da main
class MainTest {

	//Testa se a construção deu certo
    @Test
    void testConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getView());
        assertNotNull(controller.getInicializador());
        assertNotNull(controller.getPersistencia());
    }
    
    //Testa getters e setters dos atributos da classe
    @Test
    void testGetView() {
        MainController controller = new MainController("teste");
        assertTrue(controller.getView() instanceof ViewTerminal);
    }

    @Test
    void testSetView() {
        MainController controller = new MainController("teste");
        ViewTerminal novaView = new ViewTerminal();
        controller.setView(novaView);
        assertEquals(novaView, controller.getView());
    }

    @Test
    void testGetInicializador() {
        MainController controller = new MainController("teste");
        assertTrue(controller.getInicializador() instanceof InicioController);
    }

    @Test
    void testSetInicializador() {
        MainController controller = new MainController("teste");
        InicioController novoInicializador = new InicioController();
        controller.setInicializador(novoInicializador);
        assertEquals(novoInicializador, controller.getInicializador());
    }

    @Test
    void testGetPersistencia() {
        MainController controller = new MainController("teste");
        assertTrue(controller.getPersistencia() instanceof SaveObject);
    }

    @Test
    void testSetPersistencia() {
        MainController controller = new MainController("teste");
        SaveObject novaPersistencia = new SaveObject("novo.json");
        controller.setPersistencia(novaPersistencia);
        assertEquals(novaPersistencia, controller.getPersistencia());
    }
    
    //Testa se dois atributos são diferentes se os construtores são diferentes
    @Test
    void testConstrutorComNomeDiferente() {
        MainController controller1 = new MainController("jogo1");
        MainController controller2 = new MainController("jogo2");
        assertNotEquals(controller1.getPersistencia(), controller2.getPersistencia());
    }
    
    //Testa se o objeto existe após o construtor
    @Test
    void testViewNaoENulaAposConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getView());
    }

    @Test
    void testInicializadorNaoENuloAposConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getInicializador());
    }

    @Test
    void testPersistenciaNaoENulaAposConstrutor() {
        MainController controller = new MainController("teste");
        assertNotNull(controller.getPersistencia());
    }
    
    //Testagem de atributos null
    @Test
    void testSetViewComNull() {
        MainController controller = new MainController("teste");
        controller.setView(null);
        assertNull(controller.getView());
    }
    
    @Test
    void testSetInicializadorComNull() {
        MainController controller = new MainController("teste");
        controller.setInicializador(null);
        assertNull(controller.getInicializador());
    }
    
    @Test
    void testSetPersistenciaComNull() {
        MainController controller = new MainController("teste");
        controller.setPersistencia(null);
        assertNull(controller.getPersistencia());
    }
}