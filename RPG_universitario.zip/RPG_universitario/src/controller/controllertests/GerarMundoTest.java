package controller.controllertests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;

import controller.MainController;

import controller.modelcontrollers.InicioController;
import model.modelo.*;
import view.ViewTerminal;

//Classe de teste de geração de mundo
public class GerarMundoTest {
	MainController principal;
	InicioController controlador;
	ViewTerminal view;
	Random random;
	Jogo gerador;
	
	//Construtor 
	public GerarMundoTest() {
		principal = new MainController("Jogos");
		view = principal.getView();
		controlador = principal.getInicializador();
		gerador = new Jogo();
		random = new Random();
	}
	
	//Teste de criação e assertividade (verifica se o objeto criado é o mesmo que o atribuído, dentro da lista)
	@Test
	public void testeCriacao() {
		Jogo jogo = controlador.novoJogo(view.pedirNomeJogador());
		
		List<Animal> animais = jogo.getAnimais();
		List<Local> locais = jogo.getLocais();
		List<Disciplina> disciplinas = jogo.getDisciplinas();
		List<Personagem> npcs = jogo.getNpcs();
		List<Professor> professores = jogo.getProfessores();
		
		int aleatorioAnimal = random.nextInt(animais.size());
		int aleatorioLocal = random.nextInt(locais.size());
		int aleatorioDisciplina = random.nextInt(disciplinas.size());
		int aleatorioPersonagem = random.nextInt(npcs.size());
		int aleatorioProfessor = random.nextInt(professores.size());
		
		assertNotNull(jogo);
		assertEquals(animais.get(aleatorioAnimal), jogo.getAnimais().get(aleatorioAnimal));
		assertEquals(locais.get(aleatorioLocal), jogo.getLocais().get(aleatorioLocal));
		assertEquals(disciplinas.get(aleatorioDisciplina), jogo.getDisciplinas().get(aleatorioDisciplina));
		assertEquals(npcs.get(aleatorioPersonagem), jogo.getNpcs().get(aleatorioPersonagem));
		assertEquals(professores.get(aleatorioProfessor), jogo.getProfessores().get(aleatorioProfessor));
	}
	
}
